from Time import Time

class Eat:
    isEat=False
    time=None

    def __init__(self,dic) -> None:
        self.isEat = dic['isEat']
        self.time = Time(dic['time'])
