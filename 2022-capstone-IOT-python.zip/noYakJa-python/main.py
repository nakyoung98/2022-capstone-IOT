from FirebaseServer import FirebaseServer

firebase = FirebaseServer('+821062793799')

firebase.getMedicine()
